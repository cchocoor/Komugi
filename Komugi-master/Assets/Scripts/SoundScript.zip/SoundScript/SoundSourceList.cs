﻿using UnityEngine;
using System.Collections;

// BGM ===========================//
enum eBGM
{
	GAME_BGM_00 = 0,
};

// SE ===========================//
enum eSE
{
	EFFECT_02 = 0,
	EFFECT_03 = 1,
	EFFECT_01 = 2,
};

// SE ===========================//
enum eSELoop
{
	EFFECT_01 = 0,
};

// VOICE ===========================//
enum eVOICE
{
	ENEMY_VOICE_00 = 0,
	ENEMY_VOICE_01,
	ENEMY_VOICE_02,
};
